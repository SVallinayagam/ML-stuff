# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 10:59:31 2019

@author: RPS
"""

print(type("10"))
fname=input("Enter first name")
lname=input("Enter last name")
age = int(input("Enter age"))


print("First name=%s \n last name=%s \n age = %d" %(fname,lname,age))



