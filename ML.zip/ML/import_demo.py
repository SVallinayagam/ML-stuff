# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 12:24:22 2019

@author: RPS
"""

#from control_structures import dictionary, JSON, pandas, mysql_demo, missing_values

#print(generate_employee_code())
#list_demo()
#tuple_demo()
#dictionary()
#JSON()
#pandas()
#mysql_demo()
#missing_values()


from stats import missing_values, Encoder, black_friday, Normalisation, trainandtest, plot_ex, lin_regression
#missing_values()
#Encoder()
#black_friday()
#Normalisation()
#trainandtest()
#plot_ex()
lin_regression()