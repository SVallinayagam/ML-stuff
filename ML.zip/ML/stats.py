# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 16:47:47 2019

@author: RPS
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn import preprocessing 
#from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

#import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
# Missing values
def lin_regression():
    df = pd.read_csv("Salary_Data.csv")
    x = df.iloc[:,:-1].values
    y = df.iloc[:,1:2].values
    x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.3, random_state=100)
    
    model = LinearRegression()
    model.fit(x_train, y_train)
    print(x_test)
    print(model.predict(x_test))
    
    plt.title('Salary prediction')
    plt.xlabel('Years of experience')
    plt.ylabel('Salary')
    plt.scatter(x_train, y_train,color='yellow')
    plt.plot(x_test, model.predict(x_test),color = 'blue')
    plt.plot(x,y,'m.')
    plt.axis([0,15,0,150000])
    plt.grid(True)
    plt.show()
    MSE = np.mean((y_test-model.predict(x_test))**2)
    print("MSE :",MSE)
    SSE = np.sum((y_test-model.predict(x_test))**2)
    print("SSE :",SSE)
    print(y_test-model.predict(x_test))
    
    

def plot_ex():
    x = [[5],[6],[9],[14], [17]]
    print(x[0])
    y = [[6],[7],[11],[14], [16]]
    
    plt.title('pizza price')
    plt.xlabel('Diameter in inches')
    plt.ylabel('price in dollars')
    plt.plot(x,y,'m.')
    plt.axis([0,25,0,25])
    plt.grid(True)
    plt.show()
    
    #Model code
    model = LinearRegression()
    model.fit(x,y)
    print(model.predict([[14]]))
    #Mean squared error
    MSE = np.mean((14-model.predict([[14]]))**2)
    print(MSE)

def trainandtest():
    df = pd.read_csv("MSFT_Stocks.csv")
    '''
    print(df.head())
    print(df.info())
    print(df.columns())
    print(df.describe())
    print(df.shape
    '''
    #company = df.groupby("Company")
    x = df.iloc[:,1:2].values
    y = df.iloc[:,4:5].values
    #print(x,y)
    x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.3, random_state=100)
    print(x_train.shape)
    

def Normalisation():
    age = [20,30,40]
    salary = [200000,400656000,600000]
    df = pd.DataFrame({"Age":age, "Salary":salary})
    #print(df)
    x = df.values
    min_max_scalar = preprocessing.MinMaxScaler()
    x_scaled = min_max_scalar.fit_transform(x)
    df = pd.DataFrame(x_scaled)
    print(df)
    

def black_friday():
    imputer = Imputer(missing_values = 'NaN', strategy = "mean", axis = 0)
    data = pd.read_csv("BlackFriday.csv")
    x = data.iloc[:,-1].values
    x[:,9:11] = imputer.fit_transform(x[:,9:11])
    print(x[0:5,9])
    


def missing_values():
    data = pd.read_csv("missing_values.txt")
    x = data.iloc[:,:-1].values
    y = data.iloc[:,3].values
    from sklearn import preprocssing as pp
    imputer = pp.Imputer(missing_values = NaN, strategy = "mean", axis = 0)
    imputer = pp.imputer.fit(X[:,1:3])
    
def Encoder():
    from sklearn.preprocessing import LabelEncoder, OneHotEncoder
    imputer = Imputer(missing_values = 'NaN', strategy = "mean", axis = 0)
   
    #x[:,1:3] = imputer.transform([x:,1:3])
  
    data = pd.read_csv("missing_values.txt")
    #print(type(data))
    x = data.iloc[:,:-1].values
    y = data.iloc[:,3].values
    
    x = imputer.fit_transform(x[:,1:3])
    #print(type(x))
    '''
    #Label Encoder
    labencode_y = LabelEncoder()
    y = labencode_y.fit_transform(y)
    print(y)

    labencode_x = LabelEncoder()
    x[:, 0] = labencode_x.fit_transform(x[:, 0])
    print(x[:, 0])
    '''    
    #OneHotEncoder
   
    onehot_x = OneHotEncoder(categorical_features = [0])
    z = onehot_x.fit_transform(x).toarray()
    print(type(z[:,0:4]))
       

def histo_demo():
    # Histogram
    x = [20,1,2,3,7,79,45,67,34,32,58,78,99]
    num_bins = 4
    n, bins, patches = plt.hist(x,num_bins,alpha=0.5)
    print("")



